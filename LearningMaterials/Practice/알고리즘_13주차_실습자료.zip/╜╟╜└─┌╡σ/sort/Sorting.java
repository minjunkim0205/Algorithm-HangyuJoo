package sort;

public class Sorting {
	public static void insertionSort(int[] a) {
		
	}
	
	public static void selectionSort(int[] a) {

	}
	
	public static void bubbleSort(int[] a) {

	}
	
	private static void swap(int[] a, int j, int k) {
		int temp = a[j];
		a[j] = a[k];
		a[k] = temp;
	}
	
}
