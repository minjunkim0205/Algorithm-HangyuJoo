package graph1.copy;

public class Node {
	int vertex;
	Node link;
}
