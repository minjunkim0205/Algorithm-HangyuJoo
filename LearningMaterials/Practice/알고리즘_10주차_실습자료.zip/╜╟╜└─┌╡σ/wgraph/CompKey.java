package wgraph;

interface CompKey {
	public int compareTo(Object o);
}
