package binary;

class TreeNode {
    String key;
    TreeNode Lchild;
    TreeNode Rchild;
}
