# Week06b

> 2024/10/11 실습 수업

## Preview

> 공결 써서 수업 안갔음

## TODO

- [ ] ?

## Contents

- ## ?

    > ?
